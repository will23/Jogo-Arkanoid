﻿using UnityEngine;
using System.Collections;

public class GeradorDeBlocos : MonoBehaviour {


    /*
     * Vetor de blocos baseado em um objeto do jogo,
     * para ser criado dinamicamente.
     */
    public GameObject[] blocos;
    public int linhas;

	// Use this for initialization
	void Start () {

        CriarGrupoDeBlocos();


	}

    //Função resposável por criar os blocos dinamicamente
    void CriarGrupoDeBlocos()
    {
        /*
         * Largura do bloco.( um unidades do mundo).
         * Vetor de blocos, para conseguir a largura do bloco.
         */

        //Limite do bloco, bounds
        //é um retangulo que contem todo o sprite

        Bounds limiteDoBloco = blocos[0].GetComponent<SpriteRenderer>().bounds;

        //Limite em x do bloco
        float larguraDoBloco = limiteDoBloco.size.x;
        float alturaDoBloco = limiteDoBloco.size.y;
        float larguraDaTela, alturaDaTela, multiplicadorDaLargura;
        int colunas;
        ColetarDados(larguraDoBloco, out larguraDaTela, out alturaDaTela, out colunas, out multiplicadorDaLargura);

        GerenciadorDoJogo.numeroTotalDeBlocos = linhas * colunas;


        //Tela 2D, linhas e colunas Matriz para colocar os blocos na tela
        for (int i = 0; i < linhas; i++)
        {
            for (int j = 0; j < colunas; j++)
            {
                //Length retorna o maior vetor
                //Escolher o bloco aleatoriamente
                int indice = Random.Range(0, blocos.Length);
                GameObject blocoAleatorio = blocos[indice];
                GameObject blocoInstanciado = (GameObject)Instantiate(blocoAleatorio);
                //index 1 em z pois trabalhos com 1 desde o inicio
                blocoInstanciado.transform.position = new Vector3(-(larguraDaTela * 0.5f) + (j * larguraDoBloco * multiplicadorDaLargura), (alturaDaTela * 0.5f) - (i * alturaDoBloco), 1);
                float novaLarguraDoBloco = blocoInstanciado.transform.localScale.x * multiplicadorDaLargura;
                blocoInstanciado.transform.localScale = new Vector3(novaLarguraDoBloco, blocoInstanciado.transform.localScale.y, 1);

            
            
            }
        }

    }

    //Todos os dados necessários para criar os blocos dinamicamente
    void ColetarDados(float larguraDoBloco, out float larguraDaTela, out float alturaDaTela, out int colunas,
        out float multiplicadorDaLargura)
    {
        Camera c = Camera.main;
        larguraDaTela = (c.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)) - c.ScreenToWorldPoint(new Vector3(0, 0, 0))).x;
        alturaDaTela = (c.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)) - c.ScreenToWorldPoint(new Vector3(0, 0, 0))).y;

        //Casting --> Conversão de tipo dinamica
        colunas = (int)(larguraDaTela / larguraDoBloco);

        multiplicadorDaLargura = larguraDaTela / (colunas * larguraDoBloco);

    //Numero de colunas maximas escritas,
    //Preciso do tamanho necessário para preencher toda a tela na horizontal.



    }

}
