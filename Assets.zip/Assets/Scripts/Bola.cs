﻿using UnityEngine;
using System.Collections;

public class Bola : MonoBehaviour {

    /*
     * Vetor --> Sai da origem até o ponto cartesiano em questão.
     * 
     * Direção --> Represanta o movimento no plano cartesiano na bola.
     * 
     * 
     * Tamanho --> O tamanho pode ser disprezado
     * */
    //Vetor de direcao(x,y)
    public Vector3 direcao;
    public float velocidade;

    public bool checkBolinha = false;

	// Use this for initialization
	void Start () {

        direcao.Normalize();


	}
	
	// Update is called once per frame
	void Update () {
	//Alterando a posição da bola
        //O vetor de direção representa a direção do movimento
        //velocidade, representa a dimensão do vetor.
        transform.position += direcao * velocidade * Time.deltaTime;

        if (checkBolinha  && Input.GetKeyDown("space"))
        {
            LancarBolinha();
            checkBolinha = false;
        }
	}

    void OnCollisionEnter2D(Collision2D colisor)
    {
       


        /*
         * contacts[] --> vetor de possiveis locais de colisão.
         */

        //Normal da colisão com a parede para refletir o movimento.
        Vector2 normal = colisor.contacts[0].normal;
       
        //Pegando o colisor no momento que colidi.

        GeradorDeArestas geradorDeArestas = colisor.transform.GetComponent<GeradorDeArestas>();
        Plataforma plataforma = colisor.transform.GetComponent<Plataforma>();


        bool colisaoInvalida = false;


        //Perguntar com qual elemento houve a colisão
        //Se ele existe
        if (geradorDeArestas != null)
        {
            if (normal == Vector2.up)
            {
                //GameOver
                //print("GameOver Caiu embaixo!");

                colisaoInvalida = true;
            }
        }
        else if (plataforma != null)
        {
            //Bolinha tocou na plataforma de forma indevida
            if (normal != Vector2.up)
            {
                //GameOver
                //print("GameOver Local indevido");

                colisaoInvalida = true;
            }
        }
        else
        {

            //colidindo com o bloco
            colisaoInvalida = false;
            //destruir bloco instantaneamente. A referencia ao objeto some. Objeto não existira mais na cena
            //com isso quanlqueer alteração posterior a sua posição, tamanho ou qualkquer componente.
            //Se colocar , (coliso.gameObject,2) destroi em 2 segundos
            Destroy(colisor.gameObject);
            GerenciadorDoJogo.numeroDeBlocosDestruidos++;
            GerenciadorDoJogo.calcularPontos += 100;
            print(GerenciadorDoJogo.calcularPontos);

        }

        if (colisaoInvalida)
        {
            GerenciadorDoJogo.numeroDeVidas--;

            if (GerenciadorDoJogo.numeroDeVidas <= 0)
            {
                GerenciadorDoJogo.instancia.FinalizarJogo();
            }
            else
            {
               
                transform.position = new Vector3(0,0,1);
                velocidade = 0;
                checkBolinha = true;

            }


            print(GerenciadorDoJogo.numeroDeVidas);

        }
        else
        {
            //Refletir o vetor do movimento
            //Valor da direção refletida
            direcao = Vector2.Reflect(direcao, normal);
            direcao.Normalize();

        }
    }

    public void LancarBolinha()
    {
        velocidade = 10;
        direcao = Vector2.Reflect(direcao, Vector3.up);
        direcao.Normalize();

    }


}
