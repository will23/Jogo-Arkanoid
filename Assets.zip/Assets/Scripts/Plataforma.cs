﻿using UnityEngine;
using System.Collections;

public class Plataforma : MonoBehaviour {

    public float velocidadeDeMovimento;
    public float limiteEmX;
	// Use this for initialization
	void Start () {
	
        // Horizontal 
        // - 0 + 

        limiteEmX = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x
            - GetComponent<SpriteRenderer>().bounds.extents.x;



	}
	
	// Update is called once per frame
	void Update () {

        // -1 = 0 Esquerdo , 0 = 1 Direito
        float direcaoHorizontalDoMouse = Input.GetAxis("Mouse X");
        float direcaoHorizontalDoMouse2 = Input.GetAxisRaw("Horizontal");
       
        GetComponent<Transform>().position += Vector3.right *direcaoHorizontalDoMouse * velocidadeDeMovimento * Time.deltaTime;
        GetComponent<Transform>().position += Vector3.right * direcaoHorizontalDoMouse2 * velocidadeDeMovimento * Time.deltaTime;

        //Posição atual da plataforma
        float xAtual = transform.position.x;

        //Mathf ---> Cria um intervalo entre as posições dos limites passados.
        xAtual = Mathf.Clamp(xAtual, -limiteEmX, limiteEmX);
        //Passa a nova posição para a plataforma.
        transform.position = new Vector3(xAtual, transform.position.y, transform.position.z);


	}
}
