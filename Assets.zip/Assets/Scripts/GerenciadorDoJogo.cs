﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GerenciadorDoJogo : MonoBehaviour {

    /*
     * Método responsavel por finalizar o Jogo.
     */

    public static int numeroTotalDeBlocos;
    public static int numeroDeBlocosDestruidos;
    public Image estrelas;

    public GameObject canvas;
    public GameObject canvasJogo;
    public Text score;


    public Plataforma plataforma;
    public Bola bola;
    
    public static int numeroDeVidas;
    public int pontos;
    public static float calcularPontos;
    

    public static GerenciadorDoJogo instancia;

    void Awake()
    {
        instancia = this;
    }

    void Start()
    {
        if (Application.loadedLevel == 1)
        {
            // Mostrar o canvas na tela, False não mostra.
            canvas.SetActive(false);
            numeroDeBlocosDestruidos = 0;
            numeroDeVidas = 3;
            calcularPontos = 0;

        }

    }


    public void Update()
    {
        score.text = "SCORE : " + calcularPontos.ToString();
   
    }

    public  void FinalizarJogo()
    {

        // Application.LoadLevel("CenaPrincipal");
        //  UnityEngine.SceneManagement.SceneManager.LoadScene("CenaPrincipal");
        // lógica para preencher a estrela de acordo com a quantidade
        // de blocos destruidos. 0, 1
        estrelas.fillAmount = (float)numeroDeBlocosDestruidos / (float)numeroTotalDeBlocos;
        canvas.SetActive(true);
        plataforma.enabled = false;
        Destroy(bola.gameObject);

    }

    public void CarregarCena(string cena)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(cena);
    }

    public void SairDoJogo()
    {
        // Fechar o Jogo Somente quando for um executavel.
        Application.Quit();
    }
    protected bool paused;

    void OnPauseGame()
    {

        paused = true;

    }

    void OnResumeGame()
    {
        paused = false;
    }

}
